import './App.css';
import Chatbot from './components/chatbot/chatbot';

function App() {
  return (
    <div>
      <Chatbot />
    </div>
  );
}

export default App;
